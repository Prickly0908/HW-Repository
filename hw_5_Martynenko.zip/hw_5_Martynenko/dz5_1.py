import argparse
import math


def parse_args():
    parser = argparse.ArgumentParser(description='Simple input for quadratic equation Ax^2 + Bx + C = 0')

    parser.add_argument('--a', type=float, required=True, help='Coefficient A')

    parser.add_argument('--b', type=float, required=True, help='Coefficient B')
    parser.add_argument('--c', type=float, required=True, help='Coefficient B')
    return parser.parse_args()

args = parse_args()


def calc(a,b,c):

    d = math.pow(b, 2) - 4 * a * c
    x1 = (-b + math.sqrt(d)) / (2 * a)
    x2 = (-b - math.sqrt(d)) / (2 * a)
    return d,x1,x2


if __name__=='__main__':
    print(calc(args.a,args.b,args.c))