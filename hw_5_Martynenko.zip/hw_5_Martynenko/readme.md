Фаил dz5.py
Несколько вариантов конфигурационных файлов - папка configuration
Образец вызова через терминал
python dz5.py --path  /home/ubuntu/pythonProject/hyllel/configuration/koeficient1.json
python dz5.py --path  /home/ubuntu/pythonProject/hyllel/configuration/koeficient.json
python dz5.py --path  /home/ubuntu/pythonProject/hyllel/configuration/koeficient2.json

Фаил dz5_1.py
Образец вызова через терминал
python dz5_1.py --a 1 --b 6 --c -7

