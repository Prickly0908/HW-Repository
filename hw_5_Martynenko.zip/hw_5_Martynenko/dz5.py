import logging
import math
import argparse
import json

def parse_args():
    parser=argparse.ArgumentParser(description='JSON path analysis')
    parser.add_argument('--path',type=str,required=True,
                        help='path to specification')

    return parser.parse_args()

args=parse_args()
print(args.path)

path_config= args.path
configs=open(path_config)

config=json.loads(configs.read())

a=config['a']
b=config['b']
c=config['c']

logging.basicConfig(level=logging.DEBUG,
                    filename='app_test.log',
                    filemode="w")

logging.info("Start program")

try:
    d=math.pow(b,2)-4*a*c
    logging.info(f'descreminant={d}')
    x1 = (-b + math.sqrt(d)) / (2 * a)
    x2 = (-b - math.sqrt(d)) / (2 * a)
    logging.info((f'x1:{x1} x2:{x2}'))

except:
    logging.info('D<0')

finally:
    logging.info("End Program")